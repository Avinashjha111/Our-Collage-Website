<?php session_start(); ?>
<h2>Welcome Teacher: <?php echo $_SESSION['username']; ?></h2>