<?php session_start(); ?>
<h2>Welcome Student: <?php echo $_SESSION['username']; ?></h2>