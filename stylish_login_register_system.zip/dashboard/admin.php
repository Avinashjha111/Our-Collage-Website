<?php session_start(); ?>
<h2>Welcome Admin: <?php echo $_SESSION['username']; ?></h2>