<?php
include 'db.php';
session_start();

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='$role'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    header("Location: dashboard/{$role}.php");
} else {
    echo "Invalid login credentials.";
}
?>