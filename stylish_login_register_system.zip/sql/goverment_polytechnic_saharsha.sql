
CREATE DATABASE IF NOT EXISTS goverment_polytechnic_saharsha;
USE goverment_polytechnic_saharsha;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin', 'teacher', 'student') NOT NULL
);
