<?php
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
if ($conn->query($sql) === TRUE) {
    echo "Registered successfully. <a href='index.php'>Login</a>";
} else {
    echo "Error: " . $conn->error;
}
?>